-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 05-06-2016 a las 19:08:54
-- Versión del servidor: 5.5.24-log
-- Versión de PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `proyecto`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

CREATE TABLE IF NOT EXISTS `categoria` (
  `id_categoria` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_categoria` varchar(50) NOT NULL,
  PRIMARY KEY (`id_categoria`),
  UNIQUE KEY `nombre_categoria` (`nombre_categoria`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `categoria`
--

INSERT INTO `categoria` (`id_categoria`, `nombre_categoria`) VALUES
(2, 'juegos de cartas'),
(1, 'juegos de mesa'),
(3, 'juegos de rol'),
(4, 'video juegos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eventos`
--

CREATE TABLE IF NOT EXISTS `eventos` (
  `id_eventos` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(100) NOT NULL,
  `cuerpo` varchar(255) NOT NULL,
  `nombre_categoria` varchar(50) NOT NULL,
  `id_juegos` int(11) NOT NULL,
  `id_tiendas` int(11) NOT NULL,
  PRIMARY KEY (`id_eventos`),
  KEY `nombre_categoria` (`nombre_categoria`),
  KEY `id_juegos` (`id_juegos`),
  KEY `id_tiendas` (`id_tiendas`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Volcado de datos para la tabla `eventos`
--

INSERT INTO `eventos` (`id_eventos`, `titulo`, `cuerpo`, `nombre_categoria`, `id_juegos`, `id_tiendas`) VALUES
(8, 'Torneo Especial', 'Entre los dias 03 y 05 de Junio se disputara un torneo de Magic para ver quien es el mejor de Madrid. El torneo contara con grandes premios para los equipos ganadores. No dudeis en apuntaros.', 'juegos de cartas', 8, 4),
(17, 'Evento 1', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc accumsan tempus est et tempor. Donec sit amet tempor sapien. Aenean sollicitudin risus mollis sapien efficitur fermentum. Nam sed sodales arcu. In eu porttitor turpis. Ut varius nisi eu est por', 'Juegos de Cartas', 9, 5),
(18, 'Evento 2', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc accumsan tempus est et tempor. Donec sit amet tempor sapien. Aenean sollicitudin risus mollis sapien efficitur fermentum. Nam sed sodales arcu. In eu porttitor turpis. Ut varius nisi eu est por', 'Juegos de Cartas', 10, 6),
(19, 'Evento 3', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc accumsan tempus est et tempor. Donec sit amet tempor sapien. Aenean sollicitudin risus mollis sapien efficitur fermentum. Nam sed sodales arcu. In eu porttitor turpis. Ut varius nisi eu est por', 'Juegos de Mesa', 5, 1),
(20, 'Evento 4', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum a risus tellus. Proin sed rhoncus ex, a volutpat urna. Aliquam maximus augue vitae leo luctus, vitae dapibus ex scelerisque. Nunc lacus arcu, finibus ac tortor eget, tempus sagittis augue', 'Juegos de Cartas', 8, 4),
(21, 'Evento 5', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum a risus tellus. Proin sed rhoncus ex, a volutpat urna. Aliquam maximus augue vitae leo luctus, vitae dapibus ex scelerisque. Nunc lacus arcu, finibus ac tortor eget, tempus sagittis augue', 'Juegos de Rol', 11, 7),
(22, 'Evento 6', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc in nunc vel eros posuere placerat dapibus non purus. Cras viverra tincidunt porta. Vestibulum eu placerat quam. Nullam non arcu quis ligula lobortis fringilla. Morbi vestibulum neque convallis ', 'Video Juegos', 14, 11),
(23, 'Evento 8', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc in nunc vel eros posuere placerat dapibus non purus. Cras viverra tincidunt porta. Vestibulum eu placerat quam. Nullam non arcu quis ligula lobortis fringilla. Morbi vestibulum neque convallis ', 'Juegos de Rol', 11, 7),
(24, 'Evento 9', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc in nunc vel eros posuere placerat dapibus non purus. Cras viverra tincidunt porta. Vestibulum eu placerat quam. Nullam non arcu quis ligula lobortis fringilla. Morbi vestibulum neque convallis ', 'Video Juegos', 14, 11),
(25, 'Evento 22', 'Hola hola nanananananana batman miau miau miau miau miau', 'Juegos de Cartas', 8, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `juegos`
--

CREATE TABLE IF NOT EXISTS `juegos` (
  `id_juegos` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `numJugadores` int(11) NOT NULL,
  `edades` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  PRIMARY KEY (`id_juegos`),
  KEY `id_categoria` (`id_categoria`),
  KEY `id_categoria_2` (`id_categoria`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Volcado de datos para la tabla `juegos`
--

INSERT INTO `juegos` (`id_juegos`, `nombre`, `numJugadores`, `edades`, `id_categoria`) VALUES
(5, 'catan', 6, 10, 1),
(6, 'risk', 6, 12, 1),
(7, 'monopoli', 8, 10, 1),
(8, 'magic', 2, 13, 2),
(9, 'uno', 10, 7, 2),
(10, 'munchkin', 6, 12, 2),
(11, 'dungeons and dragons', 6, 12, 3),
(12, 'la llamada de cthulhu', 6, 12, 3),
(13, 'dark heresy', 6, 12, 3),
(14, 'the division', 1, 14, 4),
(17, 'black desert', 1, 14, 4),
(18, 'counter strike global offensive', 1, 14, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `noticias`
--

CREATE TABLE IF NOT EXISTS `noticias` (
  `id_noticias` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(60) NOT NULL,
  `cuerpo` varchar(255) NOT NULL,
  `id_juegos` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  PRIMARY KEY (`id_noticias`),
  KEY `id_juegos` (`id_juegos`),
  KEY `id_categoria` (`id_categoria`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Volcado de datos para la tabla `noticias`
--

INSERT INTO `noticias` (`id_noticias`, `titulo`, `cuerpo`, `id_juegos`, `id_categoria`) VALUES
(1, 'Splinter Twin ( Magic )', 'Splinter Twin es un mazo de combo para Modern. Se basa en la sinergia de la carta Splinter Twin combada con cartas que enderezan la criatura encantada, para llenar la mesa de infinitas criaturas (las que nos sean necesarias para matar al rival en un turno', 8, 2),
(2, 'Mono Blue Control ( Magic )', 'Mono Blue Control es una baraja azul de control pensada para el formato Pauper (todas las cartas de nuestro mazo son comunes). Como muchas de las barajas de control monoazul de otros formatos, este mazo gira en torno a instantaneos y conjuros que nos perm', 8, 2),
(5, 'UNO edicion Super Mario ( Uno )', 'Un nuevo producto del universo Nintendo hace acto de presencia, Amazon Japon ha mostrado una version del mitico juego de cartas UNO edicion Super Mario Bros.', 9, 2),
(6, 'Munchkin 2: Hacha Descomunal ( Munchkin )', 'Por fin. La expansion que todos esperabais Ahora con ilustraciones a todo color. 111 Cartas mas para tu juego favorito de matar monstruos y quitarles todo lo que lleven encima. Juega con una nueva raza: LOS ORCOS.', 10, 2),
(7, 'Noticia 1 ( Munchkin )', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc in nunc vel eros posuere placerat dapibus non purus. Cras viverra tincidunt porta. Vestibulum eu placerat quam. Nullam non arcu quis ligula lobortis fringilla. Morbi vestibulum neque convallis ', 10, 2),
(8, 'Noticia 2 ( Catan )', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc in nunc vel eros posuere placerat dapibus non purus. Cras viverra tincidunt porta. Vestibulum eu placerat quam. Nullam non arcu quis ligula lobortis fringilla. Morbi vestibulum neque convallis ', 5, 1),
(9, 'Noticia 3 ( Catan )', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc in nunc vel eros posuere placerat dapibus non purus. Cras viverra tincidunt porta. Vestibulum eu placerat quam. Nullam non arcu quis ligula lobortis fringilla. Morbi vestibulum neque convallis ', 5, 1),
(10, 'Noticia 4 ( Monopoli )', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc in nunc vel eros posuere placerat dapibus non purus. Cras viverra tincidunt porta. Vestibulum eu placerat quam. Nullam non arcu quis ligula lobortis fringilla. Morbi vestibulum neque convallis ', 7, 1),
(11, 'Noticia 5 ( Risk )', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc in nunc vel eros posuere placerat dapibus non purus. Cras viverra tincidunt porta. Vestibulum eu placerat quam. Nullam non arcu quis ligula lobortis fringilla. Morbi vestibulum neque convallis ', 6, 1),
(12, 'Noticia 6 ( Monopoli )', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc in nunc vel eros posuere placerat dapibus non purus. Cras viverra tincidunt porta. Vestibulum eu placerat quam. Nullam non arcu quis ligula lobortis fringilla. Morbi vestibulum neque convallis ', 7, 1),
(13, 'Noticia 7 ( Risk )', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc in nunc vel eros posuere placerat dapibus non purus. Cras viverra tincidunt porta. Vestibulum eu placerat quam. Nullam non arcu quis ligula lobortis fringilla. Morbi vestibulum neque convallis ', 6, 1),
(14, 'Noticia 1 ( Dungeons and Dragons )', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc in nunc vel eros posuere placerat dapibus non purus. Cras viverra tincidunt porta. Vestibulum eu placerat quam. Nullam non arcu quis ligula lobortis fringilla. Morbi vestibulum neque convallis ', 11, 3),
(15, 'Noticia 8 ( La llamada de Cthulhu)', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc in nunc vel eros posuere placerat dapibus non purus. Cras viverra tincidunt porta. Vestibulum eu placerat quam. Nullam non arcu quis ligula lobortis fringilla. Morbi vestibulum neque convallis ', 12, 3),
(16, 'Noticia 9 ( Dark Heresy )', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc in nunc vel eros posuere placerat dapibus non purus. Cras viverra tincidunt porta. Vestibulum eu placerat quam. Nullam non arcu quis ligula lobortis fringilla. Morbi vestibulum neque convallis ', 13, 3),
(17, 'Noticia 10 ( Dungeons and Dragons )', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc in nunc vel eros posuere placerat dapibus non purus. Cras viverra tincidunt porta. Vestibulum eu placerat quam. Nullam non arcu quis ligula lobortis fringilla. Morbi vestibulum neque convallis ', 11, 3),
(18, 'Noticia 11 ( La llamada de Cthulhu)', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc in nunc vel eros posuere placerat dapibus non purus. Cras viverra tincidunt porta. Vestibulum eu placerat quam. Nullam non arcu quis ligula lobortis fringilla. Morbi vestibulum neque convallis ', 12, 3),
(19, 'Noticia 12 ( Dark Heresy )', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc in nunc vel eros posuere placerat dapibus non purus. Cras viverra tincidunt porta. Vestibulum eu placerat quam. Nullam non arcu quis ligula lobortis fringilla. Morbi vestibulum neque convallis ', 13, 3),
(20, 'Noticia 13 ( The Division )', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc in nunc vel eros posuere placerat dapibus non purus. Cras viverra tincidunt porta. Vestibulum eu placerat quam. Nullam non arcu quis ligula lobortis fringilla. Morbi vestibulum neque convallis ', 14, 4),
(21, 'Noticia 14 ( The Division )', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc in nunc vel eros posuere placerat dapibus non purus. Cras viverra tincidunt porta. Vestibulum eu placerat quam. Nullam non arcu quis ligula lobortis fringilla. Morbi vestibulum neque convallis ', 14, 4),
(22, 'Noticia 16 ( Black Desert )', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc in nunc vel eros posuere placerat dapibus non purus. Cras viverra tincidunt porta. Vestibulum eu placerat quam. Nullam non arcu quis ligula lobortis fringilla. Morbi vestibulum neque convallis ', 17, 4),
(23, 'Noticia 17 ( Counter Strike )', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc in nunc vel eros posuere placerat dapibus non purus. Cras viverra tincidunt porta. Vestibulum eu placerat quam. Nullam non arcu quis ligula lobortis fringilla. Morbi vestibulum neque convallis ', 18, 4),
(24, 'Noticia 19 ( Counter Strike )', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc in nunc vel eros posuere placerat dapibus non purus. Cras viverra tincidunt porta. Vestibulum eu placerat quam. Nullam non arcu quis ligula lobortis fringilla. Morbi vestibulum neque convallis ', 18, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tiendas`
--

CREATE TABLE IF NOT EXISTS `tiendas` (
  `id_tiendas` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  `id_juegos` int(11) NOT NULL,
  PRIMARY KEY (`id_tiendas`),
  KEY `id_juegos` (`id_juegos`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Volcado de datos para la tabla `tiendas`
--

INSERT INTO `tiendas` (`id_tiendas`, `nombre`, `direccion`, `id_juegos`) VALUES
(1, 'Game Zone', 'Plaza Asturias 12, Getafe', 5),
(2, 'Game Wars', 'Calle de la trinidad 5, Fuenlabrada', 6),
(3, 'Jugoteca', 'Calle de las nacionalidades 13, Madrid', 7),
(4, 'CiberPunk', 'Plaza de los reyes Catolicos 2, Madrid', 8),
(5, 'Game Zone', 'Plaza Asturias 12, Getafe', 9),
(6, 'Game Wars', 'Calle de la trinidad 5, Fuenlabrada', 10),
(7, 'CiberPunk', 'Plaza de los reyes Catolicos 2, Madrid', 11),
(8, 'Jugoteca', 'Calle de las nacionalidades 13, Madrid', 12),
(9, 'Game Zone', 'Plaza Asturias 12, Getafe', 13),
(10, 'Game Wars', 'Calle de la trinidad 5, Fuenlabrada', 14),
(11, 'CiberPunk', 'Plaza de los reyes Catolicos 2, Madrid', 14),
(12, 'Game Zone', 'Plaza Asturias 12, Getafe', 17),
(13, 'Game Wars', 'Calle de la trinidad 5, Fuenlabrada', 18),
(14, 'Game Zone', 'Plaza Asturias 12, Getafe', 8);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `id` varchar(15) NOT NULL,
  `pass` varchar(15) NOT NULL,
  `categoria` varchar(30) NOT NULL,
  `intentos` int(11) NOT NULL DEFAULT '0',
  `estado` varchar(30) NOT NULL DEFAULT 'activado',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `pass`, `categoria`, `intentos`, `estado`) VALUES
('admin', 'admin', 'admin', 0, 'activado'),
('CiberPunk', 'ciberpunk', 'tienda', 0, 'activado'),
('jaime', 'jaime', 'usuario', 1, 'activado');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `eventos`
--
ALTER TABLE `eventos`
  ADD CONSTRAINT `eventos_ibfk_4` FOREIGN KEY (`nombre_categoria`) REFERENCES `categoria` (`nombre_categoria`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `eventos_ibfk_5` FOREIGN KEY (`id_juegos`) REFERENCES `juegos` (`id_juegos`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `eventos_ibfk_6` FOREIGN KEY (`id_tiendas`) REFERENCES `tiendas` (`id_tiendas`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `juegos`
--
ALTER TABLE `juegos`
  ADD CONSTRAINT `juegos_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `noticias`
--
ALTER TABLE `noticias`
  ADD CONSTRAINT `noticias_ibfk_1` FOREIGN KEY (`id_juegos`) REFERENCES `juegos` (`id_juegos`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `noticias_ibfk_2` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tiendas`
--
ALTER TABLE `tiendas`
  ADD CONSTRAINT `tiendas_ibfk_1` FOREIGN KEY (`id_juegos`) REFERENCES `juegos` (`id_juegos`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
